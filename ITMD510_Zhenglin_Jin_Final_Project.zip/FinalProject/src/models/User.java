package models;

@SuppressWarnings("hiding")
public interface User<manager> {

	public manager getClientInfo();
}
